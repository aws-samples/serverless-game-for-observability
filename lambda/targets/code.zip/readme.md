# Function Definition

## Requirements

### 1. Update Targets with parameters

定期从外部触发，向SQS发出增加targets的请求，由logic对接并处理
